import React from 'react';

const Home = (props) => {
  return (
    <div>
      <h2>Welcome to the Bank!</h2>
      <p>This is a very real bank, where you can store money and move it around.</p>
      <p>If you don't have any money, go get some and then give it to us.</p>
    </div>
  )
}

export default Home;